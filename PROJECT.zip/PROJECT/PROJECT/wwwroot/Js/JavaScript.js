﻿var first = document.getElementById("log-in");
var second = document.getElementById("sign-up");
var third = document.getElementById("button");

function signUp() {
	first.style.left = "-400px";
	second.style.left = "50px";
	third.style.left = "110px";
}
function log() {
	first.style.left = "50px";
	second.style.left = "450px";
	third.style.left = "0px";
}