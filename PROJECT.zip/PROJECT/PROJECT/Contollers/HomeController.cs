﻿using Microsoft.AspNetCore.Mvc;

namespace PROJECT.Contollers
{
    public class HomeController : Controller
    {
        public IActionResult loginsignup()
        {
            return View("loginsignup");
        }
        public IActionResult chart()
        {
            return View();
        }
        public IActionResult checkout()
        {
            return View();
        }
        public IActionResult homepage()
        {
            return View();
        }
    }
}
